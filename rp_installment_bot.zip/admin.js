// admin.js
console.log('هذا هو ملف admin.js - لوحة الإدارة');