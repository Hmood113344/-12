// index.js
console.log('هذا هو ملف index.js - قلب البوت + الواجهات');