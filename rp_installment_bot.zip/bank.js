// bank.js
console.log('هذا هو ملف bank.js - نظام بنك RP');