// credit.js
console.log('هذا هو ملف credit.js - التقييم الذكي');